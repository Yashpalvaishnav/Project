package com.te.assignment2;

import java.util.ArrayList;
import java.util.Scanner;

public class MainStudent {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		StudentDatabase s=new StudentDatabase(sc,new ArrayList<Student>());
		while(true)
		{
			System.out.println("1.register 2.login 3.display4.exit");
			System.out.println("Enter your choice");
			int ch = sc.nextInt();
			
			switch(ch)
			{
				case 1:s.add();
						break;
				case 2:System.out.println("enter the username");
				  String Email=sc.nextLine();  
				  sc.nextLine();
				  System.out.println("enter the name");
				  String name=sc.nextLine();
					s.login(Email, name);
						break;
				case 3:s.display();
						break;
				case 4:System.exit(0);
						
		
		
		}
			
		}
	}
}
	


