package com.te.assignment2;

public class Student {
	int id;
	String Name;
	double marks;
	String Email;
	public Student() {
		
	}

	public Student(int id, String name, double c, String email) {
		super();
		this.id = id;
		Name = name;
		this.marks = c;
		Email = email;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", Name=" + Name + ", marks=" + marks + ", Email=" + Email + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public double getMarks() {
		return marks;
	}

	

	public void setMarks(double marks) {
		this.marks = marks;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}
}
