package com.te.assignment2;

import java.util.List;
import java.util.Scanner;
import java.util.jar.Attributes.Name;

public class StudentDatabase {
	public Scanner sc;
	public List<Student> l;

	public StudentDatabase(Scanner sc, List<Student> l) {
		this.sc = sc;
		this.l = l;
	}

	public void add() {
		Student s = readStudentdetais();
		l.add(s);

	}

	public Student readStudentdetais() {
		Student s1 = new Student();
		System.out.println("Enter the id");
		int id = sc.nextInt();
		s1.setId(id);
		System.out.println("Enter the name");
		String name = sc.nextLine();
		s1.setName(name);
		sc.nextLine();

		System.out.println("Enter the marks");
		double marks = sc.nextDouble();
		s1.setMarks(marks);
		sc.nextLine();

		System.out.println("enter the Email");
		String email = sc.nextLine();
		s1.setEmail(email);
		return new Student(id, name, marks, email);
	}

	public void display() {
		if (!l.isEmpty()) {
			System.out.println("Id\t\tName\t\tmarks\t\tEmail");
			System.out.println(
					"----------------------------------------------------------------------------------------------------------");

			for (int i = 0; i < l.size(); i++) {
				System.out.println(l.get(i));
			}
		} else {
			System.out.println("List is Empty");
		}
	}

	public void login(String Email, String name) {

			if((Email.equalsIgnoreCase(Email))&(name.equalsIgnoreCase(name)) )
			{
				System.out.println("login successfull");
			}
		System.out.println("please register first");
		}
}


