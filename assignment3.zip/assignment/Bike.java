package com.te.assignment;

public abstract class Bike {
	abstract public void Ignition();
	abstract public void gearBox();
	abstract public void brake();
	abstract public void color();
	

}
