 package com.te.assignment;

public class BikeMain {

	public static void main(String[] args) {
		Driver d=new Driver();
		
		d.driver(new KTM());
		System.out.println("---------------------");
		d.driver(new R15());
		System.out.println("---------------------");
		d.driver(new RoyalEnfield());
		

	}

}
