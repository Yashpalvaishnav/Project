package com.te.assignment;

public class Driver {
	
	public void driver(Bike b) {
		b.Ignition();
		b.brake();
		b.gearBox();
		b.color();
	}

}
