package com.te.assignment;

public class R15 extends Bike {

	@Override
	public void Ignition() {
		System.out.println("Thw ignition is on");
		
	}

	@Override
	public void gearBox() {
		System.out.println("there is 6 gear system");
		
	}

	@Override
	public void brake() {
		System.out.println("ABS break system");
		
	}

	@Override
	public void color() {
		System.out.println("White and blue mix");
		
	}

}
