package com.te.assignment;

public class RoyalEnfield extends Bike {

	@Override
	public void Ignition() {
		System.out.println("Thw ignition is on");
		
	}

	@Override
	public void gearBox() {
		System.out.println("there is 6 gear system");
		
	}

	@Override
	public void brake() {
		System.out.println("ABS breaSk system");
		
	}

	@Override
	public void color() {
		System.out.println("Mate Black");
		
	}

}
